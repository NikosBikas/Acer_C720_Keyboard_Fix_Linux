# CBFixesAndTweaks
Script to automate CB C720 Keyboard Fixes

# How to use
Copy and paste these commands in a terminal window and reboot!

cd ~/Downloads; sudo apt-get -y install curl; curl -LOk https://github.com/archive/master.tar.gz; tar -zxvf master.tar.gz; cd CBFixesAndTweaks-master; sudo -E bash CBFixesAndTweaks.sh


Keyboard Hot-keys fix for the Acer C720 Chromebook

The top row multimedia keys are mapped correctly (after installing Linux they defaut to the F keys). From left to right they become: Back, Forward, Refresh, Print screen, Super, Decrease brightness, Increase brightness, Volume Mute, Decrease volume, Increase volume.
Pressing Ctrl+Alt+multimedia key emulates the function keys (F1 to F10).
The search key becomes the CAPS LOCK key.
Pressing Shift+arrow keys emulates the Home, End, Page Up and Page Down.
